@echo off
REM install.bat - Windows installer entry (double-click to run)
REM Set UTF-8 codepage, prefer pwsh, never flash-exit
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where pwsh >nul 2>nul && (
  pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
  goto :checkResult
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

:checkResult
if errorlevel 1 goto :failed

:done
echo.
echo ==================================================
echo  Install finished. You can close this window.
echo ==================================================
pause
exit /b 0

:failed
echo.
echo ==================================================
echo  Install failed. Please keep this window open and report the error above.
echo ==================================================
pause
exit /b 1
